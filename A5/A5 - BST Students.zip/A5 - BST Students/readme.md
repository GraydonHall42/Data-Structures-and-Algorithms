#To Run this program:
- run the main method in StudentListApp.java class